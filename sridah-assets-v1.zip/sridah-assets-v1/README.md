# SriDah production asset kit v1

This package freezes Step 1 (visual assets) and Step 2 (typography/design tokens) before layout work.

Assets are SVG wherever practical so they remain resolution-independent. `design-reference.png` is a raster reference board, not intended as a website asset.

Files:
- assets/sridah-wordmark.svg
- assets/sridah-mark.svg
- assets/market-compression.svg
- assets/system-architecture.svg
- assets/why-now.svg
- design-reference.png
- DESIGN-TOKENS.md

The hero market-behaviour artwork should be treated as the next high-resolution visual asset; it is intentionally not replaced by a generic area chart.
